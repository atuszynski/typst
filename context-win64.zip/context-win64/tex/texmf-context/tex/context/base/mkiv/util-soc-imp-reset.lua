local loaded   = package.loaded

loaded["socket"]         = nil
loaded["copas"]          = nil
loaded["ltn12"]          = nil
loaded["mbox"]           = nil
loaded["mime"]           = nil
loaded["socket.url"]     = nil
loaded["socket.headers"] = nil
loaded["socket.tp"]      = nil
loaded["socket.http"]    = nil
loaded["socket.ftp"]     = nil
loaded["socket.smtp"]    = nil
