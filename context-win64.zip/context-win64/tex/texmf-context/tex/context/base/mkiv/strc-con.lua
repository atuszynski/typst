if not modules then modules = { } end modules ['strc-con'] = {
    version   = 1.001,
    comment   = "companion to strc-con.mkiv",
    author    = "Hans Hagen, PRAGMA-ADE, Hasselt NL",
    copyright = "PRAGMA ADE / ConTeXt Development Team",
    license   = "see context related readme files"
}

-- empty
