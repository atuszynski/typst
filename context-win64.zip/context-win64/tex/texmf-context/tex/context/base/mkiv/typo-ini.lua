if not modules then modules = { } end modules ['typo-ini'] = {
    version   = 1.001,
    comment   = "companion to typo-ini.mkiv",
    author    = "Hans Hagen, PRAGMA-ADE, Hasselt NL",
    copyright = "PRAGMA ADE / ConTeXt Development Team",
    license   = "see context related readme files"
}

-- nothing yet

typesetters = typesetters or { }
